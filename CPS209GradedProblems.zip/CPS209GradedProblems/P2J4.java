import java.util.*;
 
public class P2J4 {
    public static void sortByElementFrequency(List<Integer> a ) {
        Map<Integer, Integer> freq = new HashMap<>();
        for( int e: a) {
            int x = freq.getOrDefault(e, 0) + 1;
            freq.put(e,x);
        }

        class FreqComp implements Comparator<Integer> {
            public int compare(Integer a, Integer b) {
                int frqA = freq.get(a);
                int frqB = freq.get(b);
                if (frqA > frqB) {return -1;}
                else if (frqB > frqA) {return 1;}
                else if (a < b) {return -1;}
                else if (b < a) {return 1;}
                return 0;
            }

        }

        Collections.sort(a, new FreqComp());
    }

    public static int median(int a, int b, int c) {
        int median;
        if (a > b && a > c) {
            if ( b > c) {
                median = b;
            }
            else {
                median = c;
            }
        }
        else if ( a < b && a < c) {
            if ( b > c) {
                median = c;
            }
            else {
                median = b;
            }
        }
        else {
            median = a;
        }
        return median;
    }

    public static List<Integer> runningMedianOfThree(List<Integer> a) {
        List<Integer> result = new ArrayList<>();
        for ( int i = 0; i < a.size(); i++) {
            if ( i < 2) { result.add(a.get(i));}
            else {
                int median = median( a.get(i-2), a.get(i-1), a.get(i));
                result.add(median);
            }
        }
        return result;
    }
    
    public static int firstMissingPositive(List<Integer> items){
       int number = 1;
       Iterator<Integer> iterator = items.iterator();
       while(iterator.hasNext()){
           if( items.indexOf(number) == -1) 
               return number;
           number = number + 1; 
       }
       return number; 
   }
   public static void addFactors(int n, List<Integer> list){
        int x = n;
        while(x%2==0){
            list.add(2);
            x/=2;
        }
        int e = (int)Math.sqrt(x);
        for(int i=3;i<=x;i+=2){
            while(x%i==0){
                list.add(i);
                x/=i;
            }
        }
        if(x>1)
        list.add(x);
    }

    public static List<Integer> factorFactorial(int n){
        List<Integer> factors = new ArrayList<Integer>();
        for(int i=2;i<=n;i++){
            addFactors(i,factors);
        }
        Collections.sort(factors);
        return factors;
    }
}