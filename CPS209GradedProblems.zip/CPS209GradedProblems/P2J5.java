import java.util.*;
import java.math.*;

class P2J5 {
   private static List<BigInteger> fibs = new ArrayList<BigInteger>();

   static {
       fibs.add(BigInteger.ONE);
       fibs.add(BigInteger.ONE);
   }

   public static List<BigInteger> fibonacciSum(BigInteger n) {
       int size = fibs.size();
       BigInteger number = fibs.get(size - 2).add(fibs.get(size - 1));
       while(n.compareTo(number) >= 0) {
           fibs.add(number);

           size = fibs.size();
           number = fibs.get(size - 2).add(fibs.get(size - 1));
       }

       List<BigInteger> resultList = new ArrayList<BigInteger>();
       BigInteger tempNumber = n; 
       for(int i=size-1; i>=0; i--) {
           if(tempNumber == BigInteger.ZERO)
               break;
           BigInteger num = fibs.get(i);
           if(num.compareTo(tempNumber) <= 0) {
               resultList.add(num);
               tempNumber = tempNumber.subtract(num);
           }
       }
       return resultList;
   }

   public static BigInteger sevenZero(int n){
       String seven = "7";
       BigInteger divisor = new BigInteger(n+"");
       for(int i = 0; i<1000;i++) {
           String zero ="";
           for(int j=0; j<1000;j++) {
               String nx = seven+ zero;
               BigInteger bn = new BigInteger(nx);
               BigInteger mod = bn.mod(divisor);
               if (mod.compareTo(new BigInteger("0")) == 0) {
                    return bn;
               }
               zero+="0";
            }
           seven+="7"; 
        }
       return new BigInteger("0");
   }
}
