import java.util.*;
public class P2J2{
    public static String removeDuplicates(String text) {
        char temp[] = text.toCharArray();
        String result = "";
        int str_length = text.length();
        for(int i = 1; i < str_length; i++){
            if(temp[i] != temp[i-1]){
                result += temp[i-1];
                
            }
            if(i == (str_length-1)){
                    result += temp[i];
            }
        }
        return result;
    }
    
    public static String uniqueCharacters(String text){ 
        StringBuffer uniqueString = new StringBuffer(); 
        for(int i=0; i<text.length();i++){ 
            char letter = text.charAt(i); 
            boolean found = false; 
            for(int j=0;j<i;j++){ 
                if(letter==text.charAt(j)){ 
                    found = true; 
                    break; 
                } 
            } 
            if(!found)
                uniqueString.append(letter); 
        } 
        return uniqueString.toString(); 
    }

    public static int countSafeSquaresRooks(int n, boolean[][] rooks) {
        int safeRows = 0;
        int safeColumns = 0;
        int[] rows = new int[n];
        int[] cols = new int[n];
        int ans = 0;
        for (int i = 0; i < n; i++) {
            rows[i] = 0;
            cols[i] = 0;
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (rooks[i][j] == true) {
                    rows[i] = 1;
                    cols[j] = 1;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            if (rows[i] == 0) {
                safeRows++;
            }
            if (cols[i] == 0) {
                safeColumns++;
            }
        }
        ans = safeRows * safeColumns;
        return ans;
    }
    
    public static int recaman(int n){
        int[] arr = new int[n+1];
        boolean[] completed = new boolean[10 * n];
        arr[0] = 0;
        completed[0] = true;
        for (int i = 1; i <=n; i++){
            int neg = arr[i - 1] - i;
            int pos = arr[i - 1] + i;
            if ((neg > 0) && (!completed[neg])){
                arr[i] = neg;
                completed[neg] = true;
            } else{
                arr[i] = pos;
                completed[pos] = true;
            }
        }
        return arr[n];
    }
}
