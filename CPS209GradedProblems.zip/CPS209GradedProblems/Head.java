import java.awt.Color;

import java.awt.Dimension;

import java.awt.Graphics;

import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;

import javax.swing.JPanel;

import javax.swing.border.BevelBorder;

public class Head extends JPanel {

      // variable to indicate whether mouse is inside or not

      private boolean mouseInside;

      // constructor

      public Head() {

            // using 500x500 size

            this.setPreferredSize(new Dimension(500, 500));

            // using a bevel border

            this.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

            // adding an instance of MyMouseListener as mouse listener

            addMouseListener(new MyMouseListener());

      }

      // private MouseAdapter class

      private class MyMouseListener extends MouseAdapter {

            @Override

            public void mouseEntered(MouseEvent arg0) {

                  // setting mouseInside to true and repainting

                  mouseInside = true;

                  repaint();

            }

            @Override

            public void mouseExited(MouseEvent arg0) {

                  // setting mouseInside to false and repainting

                  mouseInside = false;

                  repaint();

            }

      }

      @Override

      protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            // using black color, drawing a rectangle indicating hair of the person

            g.setColor(Color.BLACK);

            g.fillRect(50, 0, 350, 200);

            // using some color for the skin

            g.setColor(new Color(255, 219, 172));

            // drawing an oval shape for face

            g.fillOval(50, 50, 350, 400);

            // checking if mouse is inside

            if (mouseInside) {

                  // using white color, drawing two ovals indicating eyes

                  g.setColor(Color.WHITE);

                  g.fillOval(100, 150, 100, 50);

                  g.fillOval(250, 150, 100, 50);

                  // using black color, drawing two ovals indicating eyeballs

                  g.setColor(Color.BLACK);

                  g.fillOval(135, 160, 30, 30);

                  g.fillOval(285, 160, 30, 30);

            } else {

                  // if mouse is outside, just drawing an outline of the eye using

                  // black color, not filling

                  g.setColor(Color.BLACK);

                  g.drawOval(100, 150, 100, 50);

                  g.drawOval(250, 150, 100, 50);

            }

            //drawing an oval for mouth

            g.fillOval(175, 350, 100, 20);

      }

}