import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamExercises {
    public int countLines(Path path, int thres) throws IOException{
        Stream<String> lines = Files.lines(path); // to get lines from file
        Stream<String> l =  lines.filter(line -> line.length() >= thres); // filter lines which are less than threshold length
        return (int) l.count(); // return the number of lines
    }

    public List<String> collectWords(Path path) throws IOException{
        Stream<String> lines = Files.lines(path); // extract lines from file
        Stream<String> l = lines.map(line -> line.toLowerCase()); // convert lines to lower case
        Stream<String> words = l.map(line-> line.split("[^a-z]+")).flatMap(Arrays::stream); // split the lines to extract word using regex and then flattening the Stream<String[]> to Strema<String>
        Stream<String> noempty_word = words.filter(word -> word.length() > 0).sorted(); // removing empty words and then sorting the stream of words
        List<String> ans = noempty_word.distinct().collect(Collectors.toList()); // extracting distinct words and converting them to list
        return ans;
    }
}