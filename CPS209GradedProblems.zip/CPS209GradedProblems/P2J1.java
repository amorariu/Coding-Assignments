public class P2J1   {
    
    public static long fallingPower(int n, int k){
        long num = 1;
        if (k==1)
            return n;
        if (k==0)
            return 1;
        for (int i = 0; i < k; i++) {
            num = num * n;
            n = n-1;
        }
        return num;
    }
    
    public static int[] everyOther(int[] arr) {
        int number = 0;
        int arrayLength;
        if ((arr.length % 2) == 0){
            arrayLength = arr.length / 2;
        }
        else{
            arrayLength = arr.length/ 2 + 1;
        }
        int array[] = new int[arrayLength];
        for (int i = 0; i < arr.length; i += 2){
            array[number] = arr[i];
            number++;
        }
        return array;
    }
    
    public static int[][] createZigZag(int rows, int cols, int start){
        int[][] array = new int[rows][cols];
        int value = 0;
        int num = start;
        for (int i = 0; i < rows; i++){
            if (i % 2 == 0){
                for (int j = 0; j < cols; j++){
                    array[i][j] = num;
                    num++;
                }
            }
            else{
                value = start + ((i+1) * cols - 1);
                for (int j = 0; j < cols; j++){
                    array[i][j] = value;
                    num++;
                    value--;
                }
            }
        }
        return array;
    }
    
    public static int countInversions(int[] a) {
        int count = 0;
        if (a.length == 0){
            return count;
        }
        for (int i = 0; i < a.length; i++){
            for (int j = 0; j < a.length; j++){
            if ((i < j) && (a[i] > a[j])){
                count++;
            }
        }
    }
        return count;
    }
}