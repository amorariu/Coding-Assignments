import java.util.LinkedList;
import java.util.List;

public class Tail extends FileProcessor<List<String>>{
private int n;
private LinkedList<String> lastNLines;

public Tail(int n)
{
this.n = n;
lastNLines = new LinkedList<String>();
}
@Override
protected void startFile() {

}

@Override
protected void processLine(String line) {

if(lastNLines.size() == n)
{

lastNLines.removeFirst();
}
lastNLines.addLast(line);
}

@Override
protected List<String> endFile() {
return lastNLines;
}

}