import java.util.Random;

public class Particle {

                //coordinates

                private double x;

                private double y;

                //random number generator

                private static final Random rng=new Random();

                /**

                * constructor to initialize the particle in a random coordinate

                */

                public Particle(int width, int height) {

                                //assigning random x, y values

                                this.x = rng.nextInt(width);

                                this.y = rng.nextInt(height);

                }

               

                //getter methods

               

                public double getX() {

                                return x;

                }

                public double getY() {

                                return y;

                }

                /**

                * method to move the particles

                */

                public void move(){

                                /**

                                * Adding random gaussian distance to x and y values

                                */

                                x+=rng.nextGaussian();

                                y+=rng.nextGaussian();

                }

               

               

}