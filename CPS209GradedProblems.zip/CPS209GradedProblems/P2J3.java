import java.util.Arrays;
public class P2J3{
    public static void reverseAscendingSubarrays(int[] items){
        int start = 0;
        int[] subArray;
        for (int i = 0; i < items.length; i++){
            if (i == items.length - 1){
                if(items[items.length-1] > items[start]){
                    subArray = Arrays.copyOfRange(items,start,items.length);
                    if (subArray.length >= 1){
                         for (int j = 0; j < subArray.length; j++){
                             items[start+j] = subArray[subArray.length - j - 1];
                         }
                    }
                }
                break;
            }
            else if (items[i] > items[i+1]){
                subArray = Arrays.copyOfRange(items,start,i+1);
                if (subArray.length >= 1){
                    for (int j = 0; j < subArray.length; j++){
                        items[start+j] = subArray[subArray.length - j - 1];
                    }
                }
                start = i+1;
            }

        }
    }
    
    public static String pancakeScramble(String text){
        for (int i = 0; i < text.length(); i++){
            String l = text.substring(0,i+1);
            String r = text.substring(i+1);
            l = new StringBuilder(l).reverse().toString();
            text = l + r;
        }
        return text;
    }
    
    public static boolean isVowel(char c){
            if(c == 'a' || 
            c == 'A' || 
            c == 'e'|| 
            c == 'E' || 
            c == 'i' || 
            c == 'I'|| 
            c == 'o' || 
            c == 'O' || 
            c == 'u'|| 
            c == 'U'){
               return true;
            }
            return false;
        }
    
    public static boolean check_case(char c){
            if(c == 'a' || 
            c == 'e'|| 
            c == 'i' ||  
            c == 'o' ||  
            c == 'u'){
               return true;
            }
            return false;
        }
    
    public static String reverseVowels(String text){
        int j = 0; 
        char[] str = text.toCharArray(); 
        String vowel = ""; 
        for (int i = 0; i < str.length; i++) { 
            if (isVowel(str[i])) { 
                j++; 
                vowel += str[i]; 
            } 
        } 
        for (int i = 0; i < str.length; i++) { 
            if (isVowel(str[i])) {
                if (check_case(str[i])){
                    str[i] = Character.toLowerCase(vowel.charAt(--j));
                }
                else{
                    str[i] = Character.toUpperCase(vowel.charAt(--j));
                }
            } 
        } 
  
        return String.valueOf(str); 
    }
}
