import java.awt.GridLayout;

import javax.swing.JFrame;

public class HeadMain {

      public static void main(String[] args) {

            //creating a frame

            JFrame frame = new JFrame();

            //will exit on close

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            //using 2*2 grid layout

            frame.setLayout(new GridLayout(2, 2));

            //adding 4 heads

            frame.add(new Head());

            frame.add(new Head());

            frame.add(new Head());

            frame.add(new Head());

            //using compact size and displaying

            frame.pack();

            frame.setVisible(true);

      }

}