public class P2J9{
    public static boolean[] sumOfTwoDistinctSquares(int n) {
        boolean res[] = new boolean[n];

        int i=1, j=i+1;
  

        while((i*i + j*j) < n) {
            res[(i*i + j*j)] = true;
            j++;

            if((i*i + j*j) >= n) {
                i++;
                j = i+1;
            }
        }

        return res;
    }
  

    public static boolean[] subtractSquare(int n) {
        boolean res[] = new boolean[n];
        int move;
        for(int i=1; i<n; i++) {
            move = 1;
            while((i - move*move) >= 0) {
                if(!res[(i - move*move)]) {
                    res[i] = true;
                    break;
                }
                move++;
            }
        }
        return res;
    }
}