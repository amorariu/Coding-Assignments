import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeProblems {

   public static int countFridayThirteens(LocalDate startDate, LocalDate endDate){
       int friday13thCounter = 0;
       for(LocalDate ldt = startDate;!ldt.isAfter(endDate) ;ldt = ldt.plusDays(1)){
          if(ldt.getDayOfMonth()==13 && ldt.getDayOfWeek()==DayOfWeek.FRIDAY){
              friday13thCounter++;
           }
       }
       return friday13thCounter;
    }

   public static String dayAfterSeconds(LocalDateTime timeHere, long seconds){
       LocalDateTime futureDateTime = timeHere.plusSeconds(seconds);
       return futureDateTime.getDayOfWeek().name();
   }

   public static int whatHourIsItThere(LocalDateTime timeHere, String here, String there){
       ZonedDateTime zdtHere = timeHere.atZone(ZoneId.of(here));
       ZonedDateTime zdtThere = zdtHere.withZoneSameInstant(ZoneId.of(there));
       return zdtThere.getHour();
   }
}
