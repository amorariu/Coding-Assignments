public class Polynomial implements Comparable<Polynomial>  {

      private int[] coeff;

      public Polynomial(int[] coefficients) {

            coeff = new int[coefficients.length];

            for (int i = 0; i < coefficients.length; i++) {

                  coeff[i] = coefficients[i];

            }

      }

      @Override

      public String toString() {

            String poly = "";

            for (int i = coeff.length - 1; i >= 0; i--) {

                  if (i == 0) {

                        poly = poly + String.valueOf(coeff[i]) + "*x^"

                                    + String.valueOf(i);

                  } else {

                        poly = poly + String.valueOf(coeff[i]) + "*x^"

                                    + String.valueOf(i) + "+";

                  }

            }

            return poly;

      }

      public int getDegree() {

            int degree = 0;

            for (int i = coeff.length - 1; i >= 0; i--) {

                  if (coeff[i] != 0) {

                        degree = i;

                        break;

                  }

            }

            return degree;

      }

      public int getCoefficient(int k) {

            return coeff[k];

      }

      public long evaluate(int x) {

            int value = 0;

            for (int i = coeff.length - 1; i >= 0; i--) {

                  value = (value + (coeff[i]) * (int) Math.pow(x, i));

            }

            return value;

      }

      public Polynomial add(Polynomial other) {

            int newPolysize = Math.max(this.getDegree(), other.getDegree());

            int[] array = new int[newPolysize + 1];

            for (int i = 0; i <= this.getDegree(); i++) {

                  array[i] += coeff[i];

            }

            for (int j = 0; j <= other.getDegree(); j++) {

                  array[j] += other.getCoefficient(j);

            }

            Polynomial resultPoly = new Polynomial(array);

            return resultPoly;

      }

      public Polynomial multiply(Polynomial other) {

            int newPolysize = this.getDegree() + other.getDegree();

            int[] array = new int[newPolysize + 1];

            for (int i = 0; i <= this.getDegree(); i++) {

                  for (int j = 0; j <= other.getDegree(); j++) {

                        array[i + j] += (coeff[i] * other.getCoefficient(j));

                  }

            }

            Polynomial resultPoly = new Polynomial(array);

            return resultPoly;

      }

      @Override

      public boolean equals(Object other) {

            if (other == this) {

                  return true;

            }

            if (!(other instanceof Polynomial)) {

                  return false;

            }

            Polynomial p = (Polynomial) other;

            if (this.compareTo(p) == 0) {

                  return true;

            } else {

                  return false;

            }

      }

      @Override

      public int hashCode() {

            // using 31 as prime number used for hashing

            int prime = 31;

            // starting with result=1

            int result = 1;

            // looping through each coefficient

            for (int i = 0; i < getDegree(); i++) {

                  // multiplying prime with result, adding coeff[i], storing as new

                  // result

                  result = prime * result + coeff[i];

            }

            // returning the result.

            return result;

            // if you need a short, single line calculation, use below statement

            // instead.

            // return Arrays.hashCode(Arrays.copyOf(coeff, getDegree()));

      }

      public int compareTo(Polynomial other) {

            if (this.getDegree() > other.getDegree()) {

                  return 1;

            } else if (this.getDegree() < other.getDegree()) {

                  return -1;

            } else if (this.getDegree() == other.getDegree()) {

                  for (int i = this.getDegree(); i >= 0; i--) {

                        if (coeff[i] > other.getCoefficient(i)) {

                              return 1;

                        }

                        if (coeff[i] < other.getCoefficient(i)) {

                              return -1;

                        }

                  }

            }

            return 0;

      }

}
