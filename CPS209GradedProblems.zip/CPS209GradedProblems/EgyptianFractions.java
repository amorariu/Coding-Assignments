import java.util.*;
import java.math.*;
public class EgyptianFractions{
    public static List<BigInteger> greedy(Fraction f){
        ArrayList<BigInteger> result = new ArrayList<BigInteger>();
        BigInteger numerator = f.getNum();
        BigInteger denominator = f.getDen();
        while(f.getNum() != f.getDen()){
            if (numerator.equals(BigInteger.ZERO) || denominator.equals(BigInteger.ZERO)) {
                result.add(BigInteger.ZERO);
                break;
            }
            if (denominator.remainder(numerator).equals(BigInteger.ZERO)) {
                result.add(denominator.divide(numerator));
                break;
            }   
            if (numerator.remainder(denominator).equals(BigInteger.ZERO)) {
                result.add(numerator.divide(denominator));
                break;
            }
            if(numerator.compareTo(denominator) > 0)
                break;
            BigInteger n = (denominator.divide(numerator)).add(BigInteger.ONE); 
            result.add(n);
            numerator = (numerator.multiply(n)).subtract(denominator);
            denominator = denominator.multiply(n);
        }        
        return result;
    }
    
    public static List<BigInteger> splitting(Fraction a){
        ArrayList<BigInteger> result = new ArrayList<BigInteger>();
        return result;
    }
}
