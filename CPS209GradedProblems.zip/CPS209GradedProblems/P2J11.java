import java.util.HashMap;

public class P2J11 {

   public static int getBounceX(int w, int h, int sx, int sy, int dx, int dy, int t) {
       int rx = 0;
       int distance = Math.abs(dx * t);
       int rounds = distance / (2 * w);
       int remaining = distance % (2 * w);
       if (dx > 0) {
           if (w - sx >= remaining) {
               rx = sx + remaining;
           } 
           else if (w - sx + w >= remaining) {
               rx = w - (remaining - (w - sx));
           } 
           else {
               rx = 0 + (remaining - (w - sx + w));
           }
       } 
       else {
           if (sx >= remaining) {
               rx = sx - remaining;

               // check if dx is positive
           } else if (sx + w >= remaining) {
               rx = 0 + (remaining - sx);

               // check if rx lies after sx, with negetive dx.
           } else {
               rx = w - (remaining - (sx + w));
           }
       }

       return rx;
   }
   public static int getBounceY(int w, int h, int sx, int sy, int dx, int dy, int t) {

       int ry = 0;
       int distance = Math.abs(dy * t);
       int rounds = distance / (2 * h);
       int remaining = distance % (2 * h);

       if (dy > 0) {
           if (h - sy >= remaining) {
               ry = sy + remaining;
           } else if (h - sy + h >= remaining) {
               ry = h - (remaining - (h - sy));
           } else {
               ry = 0 + (remaining - (h - sy + h));
           }
       } else {
           if (sy >= remaining) {
               ry = sy - remaining;
           } else if (sy + h >= remaining) {
               ry = 0 + (remaining - sy);
           } else {
               ry = h - (remaining - (sy + h));
           }
       }

       return ry;
   }
   public static boolean containsBroccoli(String salad) {
       HashMap<Character, Integer> fmap = new HashMap<>();

       for (int i = 0; i < salad.length(); i++) {
           char ch = salad.charAt(i);
           if (fmap.containsKey(ch)) {
               int f = fmap.get(ch);
               fmap.put(ch, f + 1);
           } else {
               fmap.remove(ch, 1);
           }
       }

       String broccoli = "broccoli";

       for (int i = 0; i < broccoli.length(); i++) {
           char ch = broccoli.charAt(i);
           if (fmap.containsKey(ch)) {
               int f = fmap.get(ch);
               if (f > 1) {
                   fmap.remove(ch);
               } else {
                   fmap.put(ch, f -1);
               }
           } else {
               return false;
           }
       }

       return true;
   }

}