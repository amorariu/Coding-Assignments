import java.awt.Dimension;

import java.awt.Graphics;

import java.util.ArrayList;

import java.util.List;

import javax.swing.JPanel;

public class ParticleField extends JPanel {

               

                private boolean running = true;

                private List<Particle> particles = new ArrayList<Particle>();

               

                public ParticleField(int n, int width, int height) {

                                //setting preferred width and height

                                setPreferredSize(new Dimension(width, height));

                                /**

                                * initializing n number of particles and adding to list

                                */

                                for(int i=0;i<n;i++){

                                                Particle p=new Particle(width, height);

                                                particles.add(p);

                                }

                                /**

                                * Creating a thread

                                */

                                Thread thread=new Thread(new Runnable() {

                                               

                                                @Override

                                                public void run() {

                                                                /**

                                                                * looping until terminate() method is called

                                                                */

                                                                while(running){

                                                                                //sleeping for 20 ms

                                                                                try {

                                                                                                Thread.sleep(20);

                                                                                } catch (InterruptedException e) {

                                                                                                e.printStackTrace();

                                                                                }

                                                                                /**

                                                                                * moving all particles

                                                                                */

                                                                                for(int i=0;i<particles.size();i++){

                                                                                                particles.get(i).move();

                                                                                }

                                                                                repaint();

                                                                }                                             

                                                }

                                });

                                //starting the thread

                                thread.start();

                }

                @Override

                protected void paintComponent(Graphics g) {

                                for(Particle p:particles){

                                                /**

                                                * drawing all particles as a 3*3 pixel filled rectangle

                                                */

                                                int x=(int) p.getX();

                                                int y=(int) p.getY();

                                                g.fillRect(x, y, 3, 3);                         

                                }

                }

                /**

                * method to end the animation

                */

                public void terminate(){

                                running=false;

                }

}